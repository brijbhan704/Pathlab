-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2019 at 07:15 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pathlabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_test`
--

CREATE TABLE `all_test` (
  `id` int(11) NOT NULL,
  `pt_id` int(11) NOT NULL,
  `test_name` varchar(255) NOT NULL,
  `test_details` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_test`
--

INSERT INTO `all_test` (`id`, `pt_id`, `test_name`, `test_details`, `created_at`) VALUES
(1, 2, 'Maleriya', '48.099', '2019-11-04 06:45:52'),
(2, 2, 'Maleriya', '48.099', '2019-11-04 06:45:52'),
(3, 2, 'Maleriya', '48.099', '2019-11-04 06:45:52');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `age` tinyint(4) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `total_price` float(12,2) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `name`, `age`, `doctor_name`, `email`, `mobile`, `total_price`, `created`) VALUES
(1, 'Brijbhan', 25, 'Mr. Doctor', '', '8573992385', 3000.00, '2019-11-04 05:29:39'),
(2, 'Brijbhan', 22, 'Mr. Doctor', 'tiwari0186@gmail.com', '8573992385', 3000.00, '2019-11-04 05:30:30'),
(3, 'chulbul', 32, 'Mr. Pandey', 'tiwari0186@gmail.com', '8840354689', 3000.00, '2019-11-04 05:46:02');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created`) VALUES
(1, 'Super-Admin', '2019-11-06 06:59:20'),
(2, 'User', '2019-11-06 06:59:20'),
(3, 'User', '2019-11-06 06:59:20');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `test_name` varchar(255) NOT NULL,
  `price` float(12,2) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`id`, `parent_id`, `test_name`, `price`, `created`) VALUES
(1, 0, 'Fever', 0.00, '2019-11-02 12:54:29'),
(2, 0, 'Cancer', 0.00, '2019-11-02 12:54:29'),
(3, 0, 'Skin Infection', 0.00, '2019-11-05 06:30:29'),
(4, 0, 'HIV TEST', 0.00, '2019-11-05 06:30:29'),
(5, 0, 'Dibites', 0.00, '2019-11-05 06:30:29'),
(6, 0, 'Blood Test', 0.00, '2019-11-05 06:30:29'),
(7, 1, 'Fever test 0', 2500.00, '2019-11-05 06:37:56'),
(8, 1, 'Fever Test 2', 2000.00, '2019-11-05 06:37:56'),
(9, 1, 'Fever test 3', 1500.00, '2019-11-05 06:37:56'),
(10, 2, 'Cancer test 1', 3550.00, '2019-11-05 06:37:56'),
(11, 2, 'Cancer Test 3', 2570.00, '2019-11-05 06:37:56'),
(12, 3, 'Skin Test 1', 1000.00, '2019-11-05 06:37:56'),
(13, 3, 'Skin Test 2', 500.00, '2019-11-05 06:37:56'),
(14, 4, 'HIV test 1', 4000.00, '2019-11-05 06:37:56'),
(15, 5, 'Dibities Test 1', 2600.00, '2019-11-05 06:37:56'),
(16, 5, 'Dibities Test 2', 2800.00, '2019-11-05 06:37:56'),
(17, 6, 'Blood Test 1', 800.00, '2019-11-05 06:37:56'),
(18, 6, 'Blood Test 2', 1200.00, '2019-11-05 06:37:56'),
(19, 6, 'Blood test 3', 1400.00, '2019-11-05 06:37:56'),
(20, 1, 'Fever Test 4', 300.00, '2019-11-05 07:17:59'),
(21, 0, 'Allergy', 0.00, '2019-11-05 07:26:01'),
(24, 1, 'Fever Test 4', 2300.00, '2019-11-07 11:34:10'),
(34, 6, 'Blood Test 6', 700.00, '2019-11-11 13:13:45'),
(35, 1, 'Fever Test 6', 700.00, '2019-11-13 06:16:38');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'TechConfer', 'admin', 8979555556, 'admin@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2019-08-01 08:53:46');

-- --------------------------------------------------------

--
-- Table structure for table `tblcomputers`
--

CREATE TABLE `tblcomputers` (
  `ID` int(10) NOT NULL,
  `ComputerName` varchar(120) DEFAULT NULL,
  `ComputerLocation` varchar(120) DEFAULT NULL,
  `IPAdd` varchar(120) DEFAULT NULL,
  `EntryDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomputers`
--

INSERT INTO `tblcomputers` (`ID`, `ComputerName`, `ComputerLocation`, `IPAdd`, `EntryDate`) VALUES
(1, 'HellooMishra', 'B-120,Govindpuram, Ghaziabad', 'EG586665544', '2019-08-01 09:25:58'),
(2, 'ASUS', 'Cabin102', '127.0.0.2', '2019-08-01 09:26:37'),
(3, 'DELL', 'Cabin103', '127.0.0.2', '2019-08-01 09:27:04'),
(4, 'DELL', 'Cabin104', '127.0.0.3', '2019-08-01 09:30:40'),
(5, 'Asus Gaming Laptop', 'Cabin 10', '127.0.0.01', '2019-08-03 07:54:52'),
(6, 'Hp', 'Noida', '127.12.0', '2019-11-05 09:33:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `ID` int(10) NOT NULL,
  `role_id` int(11) NOT NULL,
  `EntryID` varchar(20) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `UserAddress` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `IDProof` varchar(120) DEFAULT NULL,
  `InTime` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`ID`, `role_id`, `EntryID`, `UserName`, `UserAddress`, `MobileNumber`, `Email`, `Password`, `IDProof`, `InTime`) VALUES
(1, 2, '398365517', 'Pushkar Mishra', 'B-120,Govindpuram, Ghaziabad', 4646464646, 'abc@gmail.com', 'MTIzNDUxMjM=', 'EG5866655', '2019-07-31 18:30:00'),
(2, 2, '285255862', 'Shanu Dev', 'g-110,govindpuram ghaziabad', 6546464646, 'shanu@gmail.com', 'MTIzNDUxMjM=', 'FG9777977', '2019-08-01 18:30:00'),
(3, 3, '305642534', 'Khushi Chaursia', '456 falt', 7575757575, 'k@gmail.com', 'MTIzNDUxMjM=', 'et686876878', '2019-08-03 05:44:06'),
(4, 2, '634737642', 'ABC', 'Noida, B-47 Noida Sector -63', 8573992385, 'aman@gamil.com.com', 'MTIzNDUxMjM=', '1234DFG1', '2019-08-03 07:55:41'),
(9, 3, '773303258', 'Brijbhan', 'Noida\r\nB-47 Noida Sector -63', 8573992385, 'tiwari0186@gmail.com', 'MTIzNDUxMjM=', 'ABC645FDSWWE', '2019-11-06 07:11:35'),
(10, 2, '750784279', 'Brijbhan Tiwari', 'NoidaB-47 Noida Sector -63', 8573992385, 'tiwari0186@gmail.com', 'MTIzNDUxMjM=', 'ABC645FDSWWE', '2019-11-06 07:52:34'),
(12, 2, '890807176', 'TechConfer', 'NoidaB-47 Noida Sector -63', 8573992385, 'tiwari0186@gmail.com', 'MTIzNDUxMjM=', 'ABC645FDSWWE', '2019-11-06 10:13:15'),
(13, 2, '776365782', 'Brijbhan Tiwari', 'NoidaB-47 Noida Sector -63', 8573992385, 'tiwari0186@gmail.com', 'MTIzNDUxMjM=', 'ABC645FDSWWE', '2019-11-06 10:17:50'),
(14, 3, '165146259', 'Hemraj', 'Noida-47 b block Delhi', 8976542365, 'akku@gmail.com', 'SGVsbG8xMjNA', 'ABC645FDSWWE', '2019-11-06 10:46:03'),
(15, 3, '737235033', 'Rohit', 'Noida\r\nB-47 Noida Sector -63', 8573992385, 'tiwari0186@gmail.com', 'MTIzNDU=', 'ABC645FDSWWE', '2019-11-07 08:06:56');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `created`) VALUES
(1, 'Tiwari', 'brijbhan@12354', '2019-11-02 11:06:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_test`
--
ALTER TABLE `all_test`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pt_id` (`pt_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cate_id` (`parent_id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcomputers`
--
ALTER TABLE `tblcomputers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_test`
--
ALTER TABLE `all_test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcomputers`
--
ALTER TABLE `tblcomputers`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `all_test`
--
ALTER TABLE `all_test`
  ADD CONSTRAINT `all_test_ibfk_1` FOREIGN KEY (`pt_id`) REFERENCES `patient` (`id`);

--
-- Constraints for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD CONSTRAINT `tblusers_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
